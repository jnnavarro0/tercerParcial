<?php
    //Variables
    $producto = 'Arroz';
    $precio = 3.80;
    $descripcion = "Vamos a comprar $producto";
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introducción a PHP</title>
</head>

<body>
    <h1><?php echo $descripcion; ?></h1>
    <button onclick="location.href='../index.html'">Regresar a Inicio</button>
</body>

</html>